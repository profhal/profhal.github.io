// Library: util
//
// This library consists of a collection of utility functions.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef UTIL_H
#define UTIL_H

#include <string>

using namespace std;


// Removes all leading and trailing whitespace.
//
string trim(string s);


// Returns true if the string contains any whitespace characters.
//
bool hasWhitespace(string s);


// Returns true of the string contains only digits and false otherwise.
//
bool hasOnlyDigits(string s);


// Returns a string containing all letters from the original string converted to lower case.
//
string toLower(string s);


#endif