#include "TeamManager.h"

#include <iostream>
#include <string>

#include "Team.h"
#include "util.h"

using namespace std;


// See header for description.
//
const int TeamManager::TEAM_STEP = 25;


// See header for description.
//
string TeamManager::generateRandomTeamId() const {

    // The string to return built up by beginning with an 8 and tacking on 8 more random digits.
    //
    string result = "8";

    for (int n=0; n < 8; ++n) {

        result += to_string(rand() % 10);

    }

    return result;

}



// See header for description.
//
TeamManager::TeamManager() {

    // Establish the team collection.
    //
    teams = new Team*[TEAM_STEP];
    teamCount = 0;

}



// See header for description.
//
// Since TeamManager does own the Team instances, it should delete them individually.
//
TeamManager::~TeamManager() {

    // For each team, disassociate the manager, disassociate all staff members, and delete the team.
    //
    for (int t=0; t < teamCount; ++t) {

        teams[t]->getManager()->removeTeam(teams[t]->getId());

        for (int e=0; e < teams[t]->getStaffCount(); ++e) {

            teams[t]->getStaff()[e]->removeTeam(teams[t]->getId());

        }
     
        delete teams[t];

    }
    
    // Release the array.
    //
    delete [] teams;

}



// See header for description.
//
Team* TeamManager::createTeam(string teamName, Employee* teamManager, string id) {

    // Tracks the team to be created.
    //
    Team* result = nullptr;

    // Indicates if we have good data to create the team.
    //
    bool canCreate;

    // Trim the team name.
    //
    teamName = trim(teamName);

    // Determine if we have good data and can create the team. That is, 
    //
    //    - the team name is non-null
    //    - the team manager is indeed an actual manager
    //    - the id needs to be generated or it is valid and unique id
    //
    canCreate = teamName != ""
                && teamManager != nullptr
                && teamManager->getIsManager()
                && (id == "" || (isValidId(id) && findTeamById(id) == nullptr));

    
    // Provided we can create the team...
    //
    if (canCreate) {
         
        // Generate a team id if one is needed.
        //
        if (id == "") {

            do {

                id = generateRandomTeamId();

            } while (findTeamById(id) != nullptr);

        }
        
        // Create and add the team to the collection. Increase the team collection capacity if full.
        //
        teams[teamCount++] = new Team(id, teamName, teamManager);

        if (teamCount % TEAM_STEP == 0) {

            Team** temp = new Team*[teamCount + TEAM_STEP];

            for (int t=0; t < teamCount; ++t) {

                temp[t] = teams[t];

            }

            delete [] teams;

            teams = temp;

        }
        
        result = teams[teamCount - 1];

    }


    return result;
                
}



// See header for description.
//
// TeamManager owns the teams and should delete the removed team.
//
void TeamManager::removeTeam(string id) {

    // Indicates we are still looking for the team with the provided id.
    //
    bool stillLooking = true;

    // The index of the team to be removed from the collection, if found.
    //
    int indexToRemove=0;


    // Look for the team in the collection. stillLooking with be true if the team is not found. Otherwise, 
    // indexToRemove will have the index of the team.
    //
    while (stillLooking && indexToRemove < teamCount) {

        if (teams[indexToRemove]->getId() == id) {

            stillLooking = false;

        } else {

            ++indexToRemove;

        }

    }
    
    // Provided we found the team...
    //
    if (!stillLooking) {

        // Disassociate the manager, disassociate all staff, and delete the team.
        // 
        teams[indexToRemove]->getManager()->removeTeam(teams[indexToRemove]->getId());

        for (int s=0; s < teams[indexToRemove]->getStaffCount(); ++s) {

            teams[indexToRemove]->getStaff()[s]->removeTeam(teams[indexToRemove]->getId());

        }

        delete teams[indexToRemove];

  
        // Remove the team from the collection.
        //
        for (int t=indexToRemove; t < teamCount; ++t) {

            teams[t] = teams[t+1];

        }

        --teamCount;

    }

}



// See header for description.
//
Team* TeamManager::findTeamById(string id) const {

    // The team (or null pointer) that is returned to the caller.
    //
    Team* result = nullptr;

    // An index to iterate through the employee collection.
    //
    int t=0;


    // Look through the collection for the employee with the given id.
    //  
    while (result == nullptr && t < teamCount) {

        if (teams[t]->getId() == id) {

            result = teams[t];

        } else {

            ++t;

        }

    }

    return result;

}



// See header for description.
//
TeamResultList* TeamManager::findTeamsByKeyword(string keyword) const {

    // The collection of teams to be returned.
    //
    TeamResultList* result = new TeamResultList();


    // Trim the keyword.
    //
    keyword = toLower(keyword);

    // Look for teams whose name contains the keyword and add it to the result list.
    //
    for (int t=0; t < teamCount; ++t) {

        if (toLower(teams[t]->getName()).find(keyword) != string::npos) {

            result->add(teams[t]);

        }

    }

    return result;

}



// See header for description.
//
Team* const * TeamManager::getAllTeams() const {

    return teams;

}



// See header for description.
//
int TeamManager::getTeamCount() const {

    return teamCount;

}



// See header for description.
//
bool TeamManager::isValidId(string id) const {

    return (id[0] == '8')
           && (id.length() == 9)
           && (hasOnlyDigits(id));

}


// See header for description.
//
bool TeamManager::isValidName(string name) const {

    return !(trim(name) == "");

}
