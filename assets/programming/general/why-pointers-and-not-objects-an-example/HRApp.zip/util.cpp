#include "util.h"

#include <cstring>
#include <iostream>
#include <string>

using namespace std;


// See header for description.
//
string trim(string s) {
     
    // The result. It will be built up as we analyze the supplied string.
    //
    string result = "";

    // And index to iterate through the characters of the string.
    //
    int c = 0;

    // The position of the first non-whitespace character and the last.
    //
    int first;
    int last;

    // Indicates if we found a non-whitespace character.
    //
    bool foundNonWhitespace = false;
    
    // Find the first non-whitespace character in the provided string.
    //
    while (!foundNonWhitespace && c < s.length()) {

        if (isspace(s[c])) {

            ++c;

        } else {

            foundNonWhitespace = true;

        }

    }

    first = c;

    // Now, start from the end of the string and work backwards to find the last non-whitespace character.
    //
    foundNonWhitespace = false;

    c = s.length() - 1;

    while (!foundNonWhitespace && c > first) {

        if (isspace(s[c])) {

            --c;

        } else {

            foundNonWhitespace = true;

        }

    }

    last = c;


    // Build the result string by taking the characers from the provided string between the indices fist and last, inclusive.
    //
    for (c = first; c <= last; ++c) {

        result += s[c];

    }


    return result;

}



// See header for description.
//
bool hasWhitespace(string s) {

    // Indicates we have found whitespace in the provided string.
    //
    bool whitespaceFound = false;

    // An index to iterate through the characters of the string.
    //
    int c=0;

    // Look for whitespace. If no whitespace is found, stillLooking will be true.
    //
    while (!whitespaceFound && c < s.length()) {

        if (isspace(s[c])) {

            whitespaceFound = true;
        
        } else {

            ++c;

        }

    }

    return whitespaceFound;

}



// See header for description.
//
bool hasOnlyDigits(string s) {

    // Indicates we are still looking for a digit.
    //
    bool stillLooking = true;

    // An index to iterate through the characters of the string.
    //
    int c=0;


    // Look for a non-digit. If no digits are found, stillLooking will be true.
    //
    while (stillLooking && c < s.length()) {

        if (!isdigit(s[c])) {

            stillLooking = false;
        
        } else {

            ++c;

        }

    }

    return stillLooking;

}



// See header for description.
//
string toLower(string s) {
    
    // The string to return built up by converting all the lowercase letters to uppercase and leaving 
    // all other characters alone.
    //
    string result = "";

    for (int c=0; c < s.length(); ++c) {

        result += tolower(s[c]);

    }

    return result;

}





