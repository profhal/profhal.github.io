// Class: TeamResultList
//
// This class is s simple container for storing a collection of teams where the teans are 
// acccessed as constants (i.e., you can't change a team through this type of collection).
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////#ifndef TEAMRESULTLIST_H
#ifndef TEAMRESULTLIST_H
#define TEAMRESULTLIST_H

#include "Team.h"

class TeamResultList {
private:

    // Used to grow the capacity of the team collection.
    //
    const static int TEAM_STEP;

    // The team collection and associated counter.
    //
    Team** teams;
    int teamCount;

public:
    
    TeamResultList();
    ~TeamResultList();
     
    // Adds the employee to the collection. If the supplied employee is the null pointer or if the
    // employee is already in the collection, the request is ignored.
    //
    virtual void add(Team* newTeam);


    // Provides access the team collection.
    //
    virtual const Team* const * getTeams() const;
    virtual int getTeamCount();

};


#endif