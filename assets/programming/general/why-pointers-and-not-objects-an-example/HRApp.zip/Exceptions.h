// This file contains the various exception classes used within the system. The meaning of each exception is
// contextual, depending on the class and operation involved.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

class BadManagerException {};
class BadIdException {};
class BadNameException {};
class BadTeamException {};

#endif