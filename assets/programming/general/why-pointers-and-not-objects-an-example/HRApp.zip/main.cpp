#include <iostream>

#include <cmath>
#include <ctime>

#include "HumanResourcesApp.h"
#include "util.h"

using namespace std;


int main() {

    HumanResourcesApp hrApp;

    // This application uses the random number generator so seed the generator.
    //
    srand(time(0));

    hrApp.run();
    
    return 0;

}