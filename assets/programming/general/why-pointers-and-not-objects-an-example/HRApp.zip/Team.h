// Class: Team
//
// Represents a team within the company. A team must have a manager (an employee who is a manager). The team 
// staff can be empty or consist of as many staff members as is necessary. Note that a manager cannot be 
// a staff member of a team then manage. It is okay for a manager to be on a team's staff when it's managed by a
// different manager.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef TEAM_H
#define TEAM_H

#include "Employee.h"

class Team {
private:
 
    // Used to grow the capacity of the staff collection.
    //
    static const int STAFF_STEP;

    // The team's id and name.
    //
    string id;
    string name;

    // The manager of the team.
    //
    Employee *manager;

    // The team staff collection and corresponding counter.
    //
    Employee **staff;
    int staffCount;

public:

    // Constructor:
    //
    // Initializes the team to use the supplied id, name, and manager. The following exceptions 
    // may be thrown:
    //
    //     BadIdException : The id was the empty string (when trimmed).
    //
    //     BadNameException : The name was the empty string (when trimmed).
    // 
    //     BadManagerException : The manager was the null pointer or the employee provided was not
    //                           a manager.
    //
    Team(string initId, string initName, Employee* initManager);

    // Destructor.
    //
    ~Team();

    
    // Returns the unique team id.
    //
    virtual string getId() const;


    // Updates the team name. The operation throws BadNameException if the name is the 
    // empty string (when trimmed).
    //
    virtual void setName(string newName);


    // Returns the team name.
    //
    virtual string getName() const;


    // Update the manager of the group. The operation will throw the BadManagerException if
    // the manager was the null pointer or the employee provided was not a manager.    
    //
    virtual void setManager(Employee *newManager);


    // Returns the current manager.
    //
    virtual Employee* getManager() const;


    // Adds an employee to the team staff. If the add is successful, true is returned. False is
    // returned if 
    // 
    //    - the new staff is the nullptr
    //    - the employee is already a member of the staff
    //    - the employee is the manager of the team
    //
    virtual bool addStaff(Employee *newStaff);


    // Returns true if an employee with the given id is on staff and false otherwise. If the
    // employee is not a manager, this operation always returns false.
    //
    virtual bool hasEmployeeOnStaff(string employeeId) const;


    // Removes the employee with the given id from staff if present. Otherwise, there is no 
    // change to the staff.
    //
    virtual void removeStaff(string employeeId);


    // Provides access to the team staff and count.
    //
    virtual Employee* const * getStaff() const;
    virtual int getStaffCount() const;


};

#endif