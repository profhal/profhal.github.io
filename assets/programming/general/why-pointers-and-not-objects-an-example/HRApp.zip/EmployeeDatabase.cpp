#include "EmployeeDatabase.h"

#include <cmath>
#include <fstream>
#include <iostream>
#include <string>

#include "Employee.h"
#include "Exceptions.h"
#include "Team.h"
#include "util.h"

using namespace std;

// See header for description.
//
const int EmployeeDatabase::EMPLOYEE_STEP = 25;


// See header for description.
//
void EmployeeDatabase::increaseEmployeeCapacity() {

    // Increases the capacity of the employee array.
    //
    Employee** temp = new Employee*[employeeCount + EMPLOYEE_STEP];

    for (int e=0; e < employeeCount; ++e) {

        temp[e] = employees[e];

    }

    delete [] employees;

    employees = temp;

}



// See header for description.
//
EmployeeDatabase::EmployeeDatabase() {
     
    // Prepare the employee collection.
    //
    employees = new Employee*[EMPLOYEE_STEP];
    employeeCount = 0;

}



// See header for description.
//
// Since this class owns the employees (it created them), it needs to individually delete them as well.
//
EmployeeDatabase::~EmployeeDatabase() {
    
    for (int e=0; e < employeeCount; ++e) {

        delete employees[e];

    }

    delete [] employees;

}



// See header for description.
//
bool EmployeeDatabase::loadEmployeesFromFile(string filepath) {
    
    // The file stream containing the employee data.
    //
    ifstream employeeFileIn;

    // Places to store the information read from the file. data is used to store a general read, typically
    // for determining if we have encountered a '-' indicating a new employee.
    //
    string data;
    string id;
    string firstName;
    string lastName;    
    string isManager;

    // Indicates if the data was successfully (true) extracted from the file or not (false).
    //
    bool loadSuccessful = true;

    // Open the file.
    //
    employeeFileIn.open(filepath);

    // If the opened successfully, try to load the employees. If not, log the problem and ensure false 
    // is returned.
    //
    if (employeeFileIn) {

        // We hope to read in a '-' so set data to something other than a '-'. This way, if the read fails, 
        // we know we have a non-'-' as the fisrt character.
        //
        data = "x";

        employeeFileIn >> data;

        // If the first thing in the file was a '-', then we know there are employees to load.
        //
        if (data == "-") {
            
            // Keep loading emplouyees while we find the separator.
            //
            while (data == "-") {
                
                // Load in the data from the file.
                //
                employeeFileIn >> id;
                employeeFileIn >> firstName;
                employeeFileIn >> lastName;
                employeeFileIn >> isManager;

                // Try to create the employee. Exceptions will be thrown if the id or one of the names is 
                // invalid. If the employee is successfully created, indicate if it's a manager or staff.
                // 
                try {
                     
                    employees[employeeCount++] = new Employee(id, firstName, lastName);

                    employees[employeeCount-1]->setIsManager((isManager == "true"));
                    
                    // Increase the capacity if full.
                    //
                    if (employeeCount % EMPLOYEE_STEP == 0) {

                        increaseEmployeeCapacity();

                    }
                
                } catch (...) {

                    // Log the bad data.
                    //
                    cout << "Bad employee data in file '" + filepath + "':" << endl;
                    cout << "  id: " << id << endl;
                    cout << "  first: " << id << endl;
                    cout << "  last: " << id << endl;
                    cout << "  isManager: " << isManager << endl;

                }

                // Move on to the next employee.
                //
                data = "x";

                employeeFileIn >> data;

            }

            // Close the file now that we are finished.
            //
            employeeFileIn.close();


        } else {

            cout << "Employee file '" + filepath + "' does not begin with a '-'." << endl;
    
            loadSuccessful = false;

        }
    
    } else {

        cout << "There was a problem opening the file '" + filepath + "'." << endl;
        
        loadSuccessful = false;

    }

    return loadSuccessful;
    
}



// See header for description.
//
bool EmployeeDatabase::saveEmployeesToFile(string filepath) const {
    
    // The file stream to output the employee data.
    //
    ofstream employeeFileOut;

    // Indicates whether the data was saved successfully (true) or not (false).
    //
    bool saveSuccessful = true;


    // Open the output file.
    //
    employeeFileOut.open(filepath);


    // If the file opened successfully, save the employee data. Otherwise, log the error and ensure false is 
    // returned.
    //
    if (employeeFileOut) {

        for (int e=0; e < employeeCount; ++e) {
        
            employeeFileOut << "-" << endl;
            employeeFileOut << employees[e]->getId() << endl;
            employeeFileOut << employees[e]->getFirstName() << " " << employees[e]->getLastName() << endl;
            employeeFileOut << (employees[e]->getIsManager() ? "true" : "false");

            if (e < employeeCount - 1) {
                
                employeeFileOut << endl;
            
            }
        
        }
        
        // Close the file now the we are finished.
        //
        employeeFileOut.close();
        

    } else {
        
        cout << "There was a problem opening '" + filepath + "' for saving the employee data." << endl;
        saveSuccessful = false;

    }

    return saveSuccessful;

}



// See header for description.
//
Employee* EmployeeDatabase::createEmployee(string firstName, string lastName, string id) {
    
    // The employee that gets created and returned.
    //
    Employee* result = nullptr;

    // Trim the incoming data.
    //
    firstName = trim(firstName);
    lastName = trim(lastName);
    id = trim(id);

    // Detect if we are able to create the employee by checking
    //
    // - If the first and last names are non-empty and have no whitespace.
    // 
    // - If the id is the empty string or is not the id of an existing employee.
    //
    bool canCreateEmployee = firstName != "" && lastName != "";

    canCreateEmployee = canCreateEmployee && !hasWhitespace(firstName);

    canCreateEmployee = canCreateEmployee && !hasWhitespace(lastName);

    canCreateEmployee = canCreateEmployee 
                        && ((id == "") || (id != "" && isValidId(id) && findEmployeeById(id) == nullptr));

    
    // If we can create the employee, do so. Otherwise, return the null pointer.
    //
    if (canCreateEmployee) {
        
        // If the id is the empty string, we generate a unique id.
        //
        if (id == "") {

            do {

                id = generateRandomId();

            } while (findEmployeeById(id) != nullptr);

        }
        
        // Create the employee. This should work as we looked for issues the id and names already.
        //
        employees[employeeCount++] = new Employee(id, firstName, lastName);

        // Grow the capacity of the collection if it is full.
        //
        if (employeeCount % EMPLOYEE_STEP == 0) {

            increaseEmployeeCapacity();

        }
        
        // Be sure to return the new employee.
        // 
        result = employees[employeeCount - 1];

    }
    
    return result;
     
}



// See header for description.
//
Employee* EmployeeDatabase::findEmployeeById(string id) {
    
    // The employee (or null pointer) that is returned to the caller.
    //
    Employee* result = nullptr;
 
    // An index to iterate through the employee collection.
    //
    int e=0;


    // Look through the collection for the employee with the given id.
    //  
    while ( (result == nullptr) && e < employeeCount) {

        if (employees[e]->getId() == id) {

            result = employees[e];

        } else {

            ++e;

        }

    }

    return result;
    
}



// See header for description.
//
EmployeeResultList* EmployeeDatabase::findEmployeeByNameKeyword(string keyword) const {
    
    // The collection of employees to be returned.
    //
    EmployeeResultList* result = new EmployeeResultList();


    // Trim the keyword.
    //
    keyword = toLower(keyword);

    // Look for employees whose first or last name contains the keyword and add them to the result list.
    //
    for (int e=0; e < employeeCount; ++e) {
        
        if (toLower(employees[e]->getFirstName()).find(keyword) != string::npos
            || toLower(employees[e]->getLastName()).find(keyword) != string::npos) {
            
            result->add(employees[e]);

        }

    }


    return result;

}



// See header for description.
//
// To remove an employee also requires disassociating it from any team they participate in.
//
void EmployeeDatabase::removeEmployee(string id) {

    // If an employee with the given id is in the collection, this stores its index.
    //
    int indexToRemove=0;
    
    // The employee instance with the given id.
    //
    Employee* employee;

    // Indicates if we are still searching for various values.
    //
    bool stillLooking = true;
    
    // An index to iterate through the employees team collection.
    //
    int t=0;


    // Try to find the employee in the collection.
    //
    stillLooking = true;
    indexToRemove = 0;
    
    while (stillLooking && indexToRemove < employeeCount) {

        if (employees[indexToRemove]->getId() == id) {

            stillLooking = false;

        } else {

            ++indexToRemove;

        }

    }

    // If we found an employee start to try to remove them from the collection.
    //
    if (!stillLooking) {
        
        // First, determine if the employee is a manager of any team. If they are stillLooking will be false
        // when the loop exists.
        //
        stillLooking = true;
        t = 0;

        while (stillLooking && t < employees[indexToRemove]->getTeamCount()) {

            if (employees[indexToRemove]->getId() == employees[indexToRemove]->getTeamList()[t]->getManager()->getId()) {

                stillLooking = false;
                
            } else {

                ++t;

            }

        }
        

        // If we found any employees who manage a team, throw BadIdException. A team must be deleted before its manager.
        //
        if (!stillLooking) {

            throw BadIdException();

        }


        // At this point, we know that the employee is in the list and that they do not manage an teams.
        // Disassociate the employee for all teams they are participating in, remove the employee from
        // the collection, and delete it.
        //
        employee = employees[indexToRemove];

        for (int t=0; t < employee->getTeamCount(); ++t) {

            employee->getTeamList()[t]->removeStaff(employee->getId());

        }

        for (int e=indexToRemove; e < employeeCount; ++e) {

            employees[e] = employees[e+1];

        }

        --employeeCount;

        delete employee;

    }

}



// See header for description.
//
const Employee* const * EmployeeDatabase::getEmployees() {

    return employees;

}



// See header for description.
//
int EmployeeDatabase::getEmployeeCount() const {

    return employeeCount;

}



// See header for description.
//
string EmployeeDatabase::generateRandomId() const {

        // The string to return built up by beginning with a 9 and tacking on 8 more random digits.
    //
    string result = "9";

    for (int n=0; n < 8; ++n) {

        result += to_string(rand() % 10);

    }

    return result;


}


// See header for description.
//
bool EmployeeDatabase::isValidId(string id) const {

    return (id[0] == '9')
           && (id.length() == 9)
           && (hasOnlyDigits(id));

}


// See header for description.
//
bool EmployeeDatabase::isValidName(string firstName, string lastName) const {

    firstName = trim(firstName);
    lastName = trim(lastName);

    return (firstName.length() != 0 && lastName.length() != 0);

}