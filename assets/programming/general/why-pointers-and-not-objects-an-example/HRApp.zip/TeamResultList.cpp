#include "TeamResultList.h"

#include <iostream>
#include <string>

using namespace std;

// See header for description.
//
const int TeamResultList::TEAM_STEP = 10;



// See header for description.
//
TeamResultList::TeamResultList() {

    // Establish the team collection.
    //
    teams = new Team*[TEAM_STEP];
    teamCount = 0;

}



// See header for description.
//
// This class doesn't own the Team objects so should not delete them.
//
TeamResultList::~TeamResultList() {

    delete [] teams;

}



// See header for description.
//
void TeamResultList::add(Team* newTeam) {

    // Indicates whether or not we are still searching for the team.
    //
    bool stillLooking = true;

    // An index to iterate through the team collection.
    //
    int t = 0;



    // Provided we have a team...
    //
    if (newTeam != nullptr) {

        // Determine if the team is currently in the collection. If not, stillLooking will be true.
        //
        while (stillLooking && t < teamCount) {

            if (teams[t]->getId() == newTeam->getId()) {

                stillLooking = false;

            } else {

                ++t;

            }

        }

        // If the team is new, add it to the colleciton and increase the collection capacity if it's full.
        //
        if (stillLooking) {
            
            teams[teamCount++] = newTeam;

            if (teamCount % TEAM_STEP == 0) {

                Team** temp = new Team*[teamCount + TEAM_STEP];

                for (int e=0; e < teamCount; ++e) {

                    temp[e] = teams[e];

                }

                delete [] teams;

                teams = temp;

            }

        }       

    }

}



// See header for description.
//
const Team* const * TeamResultList::getTeams() const {

    return teams;

}



// See header for description.
//
int TeamResultList::getTeamCount() {

    return teamCount;

}