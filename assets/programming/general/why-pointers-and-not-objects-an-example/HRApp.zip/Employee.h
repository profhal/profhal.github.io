// Class: Employee
//
// Reperesents an employee in the system. An employee can be a manager (getIsManager() would return true)
// or a staff member (getIsManager() would return false).
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>

using namespace std;


// Since Team and Employee are mutually dependent, we use a forward declaration here.
//
class Team;


class Employee {
private:
    
    // Used to control the growth of the capacity of the team collection.
    //
    const static int TEAM_STEP;

    // The employees id, first, and last name.
    //
    string id;
    string firstName;
    string lastName;

    // Indicates whether the employee is a manager (true) or a staff member (false).
    //
    bool isManager;

    // The collection of teams the employee is participating in and the associated counter.
    //
    Team **teamList;
    int teamCount;

public:
    
    // Initializes the employee to use the supplied id and name. The following exceptions may be 
    // thrown:
    // 
    //     BadIdException : The id was the empty string (when trimmed).
    //
    //     BadNameException : The first or last name provided was the empty string (when trimmed) or
    //                        the first or last name contained whitespace.
    //
    Employee(string id, string initFirstName, string initLastName);

    // Destructor:
    // 
    ~Employee();


    // Returns the employee id.
    //
    virtual string getId() const;


    // Updates the employee's first name. This operation will throw BadNameException if the 
    // provided name is the empty string (when trimmed) or if the name contains whitespace.
    //
    virtual void setFirstName(string newFirstName);


    // Returns the employee's first name.
    //
    virtual string getFirstName() const;


    // Updates the employee's last name. This operation will throw BadNameException if the 
    // provided name is the empty string (when trimmed) or if the name contains whitespace.
    //
    virtual void setLastName(string newLastName);


    // Returns the employee's last name.
    //
    virtual string getLastName() const;


    // Modify and retrieve the manager status.
    //  
    virtual void setIsManager(bool newIsManager);
    virtual bool getIsManager() const;


    // Adds the provided team to the list of teams this employee is participating in. If 
    // the team is already on the list, the request is ignored. 
    //
    // This operation throws BadTeamException if 
    //
    //     - the provide team is the null pointer
    //
    //     - the employee is not part of the team's staff. 
    //
    // NOTE: This means you have to add the employee to a team, before adding the team to 
    // the employee.
    //
    virtual void addTeam(Team *newTeam);


    // Removes the team from the employee's team list. If the team provided is the null pointer
    // or not among the list of teams, the request is ignored.
    //
    virtual void removeTeam(string id);


    // Returns true if the a team with the supplied id is on the employee's team list.
    //
    virtual bool hasTeam(string teamId) const;


    // Provides access to the teams the employee is participating in.
    //
    virtual Team* const * getTeamList() const;
    virtual int getTeamCount() const;

};


#endif