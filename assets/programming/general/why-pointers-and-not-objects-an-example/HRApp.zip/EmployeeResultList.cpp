#include "EmployeeDatabase.h"

#include <iostream>
#include <string>

using namespace std;


// See header for description.
//
const int EmployeeResultList::EMPLOYEE_STEP = 10;


// See header for description.
//
EmployeeResultList::EmployeeResultList() {
 
    // Establish the employee collection.
    //
    employees = new Employee*[EMPLOYEE_STEP];
    employeeCount = 0;

}



// See header for description.
//
// This class doesn't own the Employee objects so should not delete them.
//
EmployeeResultList::~EmployeeResultList() {

    delete [] employees;

}



// See header for description.
//
void EmployeeResultList::add(Employee* newEmployee) {

    // Indicates whether or not we are still searching for the employee.
    //
    bool stillLooking = true;

    // An index to iterate through the employee collection.
    //
    int e = 0;


    // Provided we have an employee...
    //
    if (newEmployee != nullptr) {

        // Determine if the employee is currently in the collection. If not, stillLooking will be true.
        //
        while (stillLooking && e < employeeCount) {

            if (employees[e]->getId() == newEmployee->getId()) {

                stillLooking = false;

            } else {

                ++e;

            }

        }

        // If the employee is new, add them to the colleciton and increase the collection capacity if 
        // it's full.
        //
        if (stillLooking) {
            
            employees[employeeCount++] = newEmployee;

            if (employeeCount % EMPLOYEE_STEP == 0) {

                Employee** temp = new Employee*[employeeCount + EMPLOYEE_STEP];

                for (int e=0; e < employeeCount; ++e) {

                    temp[e] = employees[e];

                }

                delete [] employees;

                employees = temp;

            }

        }       

    }

}



// See header for description.
//
const Employee* const * EmployeeResultList::getEmployees() const {

    return employees;

}



// See header for description.
//
int EmployeeResultList::getEmployeeCount() {

    return employeeCount;

}