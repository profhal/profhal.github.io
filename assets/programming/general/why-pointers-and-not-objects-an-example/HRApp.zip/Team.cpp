#include "Team.h"

#include <iostream>

using namespace std;

#include "Employee.h"
#include "Exceptions.h"
#include "util.h"

// See header for description.
//
const int Team::STAFF_STEP = 10;



// See header for description.
//
Team::Team(string initId, string initName, Employee* initManager) {

    // Trim the incoming strings.
    //
    initId = trim(initId);
    initName = trim(initName);

    // If the manager is invalid, throw a BadManagerException.
    //
    if (initId == "") {

        throw BadIdException();

    }

    // If the manager is invalid, throw a BadManagerException.
    //
    if (initName == "") {

        throw BadNameException();

    }

    // If the manager is invalid, throw a BadManagerException.
    //
    if (initManager == nullptr || !initManager->getIsManager()) {

        throw BadManagerException();

    }

    // Store things locally.
    //
    id = initId;
    name = initName;

    // Establish the staff collection.
    //
    staff = new Employee*[STAFF_STEP];
    staffCount = 0;

    // Keep track of the manager and tell the manaegr they are on this team.
    //
    manager = initManager;
    manager->addTeam(this);

}



// See header for description.
//
// Since a team doesn't own the employees, it doesn't delete the individual employees.
//
Team::~Team() {
    
    // Disassociate the manager and staff from this team and delete the staff container.
    //
    manager->removeTeam(id);

    for (int s=0; s < staffCount; ++s) {

        staff[s]->removeTeam(id);

    }

    delete [] staff;

}



// See header for description.
//
string Team::getId() const {
    
    return id;

}



// See header for description.
//
void Team::setName(string newName) {

    // Trim the name.
    //
    newName = trim(newName);

    // If the name is invalid, throw a BadNameException. Otherwise, save it locally.
    //
    if (newName == "") {

        throw BadNameException();

    } else {

        name = newName;

    }

}



// See header for description.
//
string Team::getName() const {

    return name;

}



// See header for description.
//
void Team::setManager(Employee *newManager) {

    // If the manager is invalid, throw a BadManagerException. Otherwise, remove the old manager (it has
    // to be a valid employee), keep track of the new manager, and tell the new manaegr they are on
    // this team.
    //
    if (newManager == nullptr || !newManager->getIsManager()) {

        throw BadManagerException();

    } else {

        manager->removeTeam(id);

        manager = newManager;

        manager->addTeam(this);

    }

}



// See header for description.
//
Employee* Team::getManager() const {

    return manager;

}



// See header for description.
//
bool Team::addStaff(Employee *newStaff) {
    
    // Indicates to the caller whether the add was successful (true) or not (false).
    //
    bool result = true;


    // Provided we have an actual employee, try to add them to the collecton. Otherwise, ensure
    // false is returned.
    //
    if (newStaff != nullptr) {

        // If the employee is already on the team, ensure false is returned. Otherwise, 
        // add the staff and increase the staff collection capacity if full.
        //
        if (hasEmployeeOnStaff(newStaff->getId())) {

            result = false;

        } else {
            
            staff[staffCount++] = newStaff;

            newStaff->addTeam(this);

            if (staffCount % STAFF_STEP == 0) {

                Employee **temp = new Employee*[staffCount + STAFF_STEP];

                for (int s=0; s < staffCount; ++s) {

                    temp[s] = staff[s];

                }

                delete [] staff;

                staff = temp;

            }

        }

    } else {

        result = false;
    }
    
    return result;

}



// See header for description.
//
bool Team::hasEmployeeOnStaff(string id) const {

    // Indicates if we are still searching for the staff member.
    //
    bool stillLooking = true;

    // An index to iterate through the staff member collection.
    //
    int s=0;


    // Trim the id. 
    //
    id = trim(id);

    // Look for the employee in the collection. If the employee is found, stillLooking will be false.
    //
    while (stillLooking && s < staffCount) {

        if (staff[s]->getId() == id) {

            stillLooking = false;

        } else {

            ++s;

        }

    }
    
    // Return the result. (If stillLooking is true, we did NOT find the employee.)
    //
    return !stillLooking;

}



// See header for description.
//
// Since Team doesn't own the staff members, it should not delete them, only remove the reference 
// from the collection.
//
void Team::removeStaff(string employeeId) {

    // Indicates if we are still looking for the staff member with the given id.
    //
    bool stillLooking = true;

    // If we find the staff member in the array, this will store it's index.
    //
    int indexToRemove = 0;
    

    // Find the index of the staff member to be removed. If the employee is not among the staff, 
    // stillLooking will be true.
    //
    while (stillLooking && indexToRemove < staffCount) {

        if (staff[indexToRemove]->getId() == employeeId) {

            stillLooking = false;

        } else {

            ++indexToRemove;

        }

    }
 
    // If we found the staff member, try to remove the team from the staff member's collection and then 
    // the staff member from the team's collection.
    //
    if (!stillLooking) {
 
        if (staff[indexToRemove]->hasTeam(id)) {

            staff[indexToRemove]->removeTeam(id);

        }

        for (int m=indexToRemove; m < staffCount-1; ++m) {

            staff[m] = staff[m+1];

        }

        --staffCount;

    }

}



// See header for description.
//
Employee* const * Team::getStaff() const {

    return staff;

}



// See header for description.
//
int Team::getStaffCount() const {

    return staffCount;

}
