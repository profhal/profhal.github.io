// Class: TeamManager
//
// This class managers a collection of teans.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////#ifndef TEAMRESULTLIST_H
#ifndef TEAMMANAGER_H
#define TEAMMANAGER_H

#include <string>

#include "Team.h"
#include "TeamResultList.h"

using namespace std;


class TeamManager {
private:

    // Used to grow the capacity of the team collection.
    //
    const static int TEAM_STEP;

    // The team collection and associated counter.
    //
    Team **teams;
    int teamCount;

    // Creates a random valid team id.
    //
    string generateRandomTeamId() const;

public:

    // Constructor.
    //
    // Prepares the team collection for use.
    //
    TeamManager();

    // Destructor.
    //
    ~TeamManager();
    

    // Returns a new team with the supplied team name and, optionally, team id. If the team id
    // supplied is empty (after trimming), a unique team id will be generated. If the team id 
    // supplied is non-empty and no team exists with the existing id, the team will be created. 
    // 
    // This operation will return the null pointer, indidcating a team wasn't created, if
    //
    //     - The team name is the empty string (after trimming)
    //     - The supplied manager is not a manager
    //
    virtual Team* createTeam(string teamName, Employee* teamManager, string id="");

 
    // Removes the team with the given id. Further, it informs the manager and all staff that the
    // team is being dissolved. If the team id does not represent a team in the collection, the 
    // request is ignored.
    //
    virtual void removeTeam(string id);


    // Returns the team in the collection with the given id or the null pointer if a team doesn't
    // exist.
    //
    virtual Team* findTeamById(string id) const;


    // Returns a collection of teams whose name contains the keyword.
    //
    // The user is responsible for deleting the collection object when done with it. 
    //
    virtual TeamResultList* findTeamsByKeyword(string keyword) const;


    // Provides access to the employee collection.
    //
    virtual Team* const * getAllTeams() const;
    virtual int getTeamCount() const;

    // Utilities to ensure an id or name is in a valid format. 
    //
    // NOTE: This only indicates a valid format. It does not indicate the id or name is in the 
    //       collection.
    //
    virtual bool isValidId(string id) const;
    virtual bool isValidName(string name) const;

};


#endif