// Class: EmployeeResultList
//
// This class is s simple container for storing a collection of employees where the employees are 
// acccessed as constants (i.e., you can't change an employee through this type of collection).
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef EMPLOYEERESULTLIST_H
#define EMPLOYEERESULTLIST_H

#include "Employee.h"

class EmployeeResultList {
private:
    
    // Used to grow the capacity of the employee collection.
    //
    const static int EMPLOYEE_STEP;

    // The employee collection and associated counter.
    //
    Employee** employees;
    int employeeCount;

public:
    
    // Contructor.
    // 
    // Prepares the collection for storing employees.
    //
    EmployeeResultList();
    
    // Destructor.
    //
    ~EmployeeResultList();


    // Adds the employee to the collection. If the supplied employee is the null pointer or if the
    // employee is already in the collection, the request is ignored.
    //
    virtual void add(Employee* newEmployee);


    // Provides access to the collection of employees.
    //
    virtual const Employee* const * getEmployees() const;
    virtual int getEmployeeCount();

};

#endif