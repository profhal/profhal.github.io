// Class: HumanResourcesApp
//
// Represents the overall HR application and proivdes the user interface to the rest of the system.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef HUMANRESOURCESAPP_H
#define HUMANRESOURCESAPP_H

#include "EmployeeDatabase.h"
#include "TeamManager.h"

class HumanResourcesApp {
private:
    
    // The employee database that manages the employees in the system.
    //
    EmployeeDatabase employeeDB;

    // The team manager that manages the teams in the system.
    //
    TeamManager teamMgr;


    // Prepares the employee database for use.
    //
    bool prepareEmployeeDatabase();
    
    
    // Prepares the team manager for use.
    //
    bool prepareTeamManager();


    // Displays the main menu and handles user choices.
    //
    void startInterface();


    // Handles adding an employee to the system.
    // 
    void doAddEmployee();
    
    
    // Handles adding a team to the system.
    // 
    void doAddTeam();
    
    
    // Handles finding an employee in the system.
    // 
    void doFindEmployee();
    
    
    // Handles finding a team in the system.
    // 
    void doFindTeam();
    
    
    // Handles removing an employee from the system.
    // 
    void doRemoveEmployee();
    
    
    // Handles finding a team in the system.
    // 
    void doRemoveTeam();
    
    
    // Handles editing an employee in the system.
    //
    // Currently, you can only edit an employee's name.
    // 
    void doEditEmployee();
    
    
    // Handles editing a team in the system.
    //
    // Currently, you can only edit a team's name.
    // 
    void doEditTeam();
    
    
    // Handles gracefully exiting the system. It provides the opportunity to save the employee a
    // and team data.
    // 
    void doQuit();
    
    // Lists the various actions the user can perform with the system.
    // 
    // ** These must be in the same order as the menu options presented to the user. **
    //
    enum Actions {ADD_EMPLOYEE, EDIT_EMPLOYEE, REMOVE_EMPLOYEE, FIND_EMPLOYEE,
                  ADD_TEAM, EDIT_TEAM, REMOVE_TEAM, FIND_TEAM, 
                  QUIT};


public:
    
    // Starts the Human Resources Application.
    //
    virtual void run();

};

#endif