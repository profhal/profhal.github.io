#include "Employee.h"

#include <string>

#include "Exceptions.h"
#include "Team.h"
#include "util.h"

using namespace std;

// See header for description.
//
const int Employee::TEAM_STEP = 5;


// See header for description.
//
Employee::Employee(string initId, string initFirstName, string initLastName) {

    // Trim the incoming strings.
    //
    initId = trim(initId);
    initFirstName = trim(initFirstName);
    initLastName = trim(initLastName);

    // If the id is invalid, throw a BadIdException.
    //
    if (initId == "") {

        throw BadIdException();

    }

    // If the name is invalid, throw a BadNameException.
    //
    if (initFirstName == "" 
        || initLastName == "" 
        || hasWhitespace(initFirstName) 
        || hasWhitespace(initLastName)) {

        throw BadNameException();

    }
  
  
    // The provided data is good, so save it locally.
    //
    id = initId;
    firstName = initFirstName;
    lastName = initLastName;

    // Indicate the employee is staff to begin with.
    //
    isManager = false;

    // Get the team collection in place.
    //
    teamList = new Team*[TEAM_STEP];
    teamCount = 0;

}


// See header for description.
//
// ALl that needs to happen is to free the team list. Since an employee doesn't create the
// teams, we don't delete them.
//
Employee::~Employee() {

    delete [] teamList;

}


// See header for description.
//
string Employee::getId() const {

    return id;

}



// See header for description.
//
void Employee::setFirstName(string newFirstName) {

    // Trim the incoming name.
    //
    newFirstName = trim(newFirstName);

    // If the name is invalid, throw a BadNameException.
    //
    if (newFirstName == "" || hasWhitespace(newFirstName)) {

        throw BadNameException();

    }

    // The name is good so remember it.
    //
    firstName = newFirstName;

}


// See header for description.
//
string Employee::getFirstName() const {

    return firstName;

}



// See header for description.
//
void Employee::setLastName(string newLastName) {

    // Trim the incoming name.
    //
    newLastName = trim(newLastName);

    // If the name is invalid, throw a BadNameException.
    //
    if (newLastName == "" || hasWhitespace(newLastName)) {

        throw BadNameException();

    }

    // The name is good so remember it.
    //
    lastName = newLastName;

}


// See header for description.
//
string Employee::getLastName() const {

    return lastName;

}


// See header for description.
//
void Employee::setIsManager(bool newIsManager) {

    isManager = newIsManager;

}


// See header for description.
//
bool Employee::getIsManager() const {

    return isManager;

}


// See header for description.
//
void Employee::addTeam(Team *newTeam) {

    // If the new team is the null pointer or the employee is not part of the team, 
    // throw a BadTeamException.
    //
    if (newTeam == nullptr
        || newTeam->getManager()->getId() != id && !newTeam->hasEmployeeOnStaff(id)) {

        throw BadTeamException();

    }

    // Assuming the team is not already on the list, add it.
    //
    if (!hasTeam(newTeam->getId())) {

        // Add the team to the list and grow the array if necessary.
        //
        teamList[teamCount++] = newTeam;

        if (teamCount % TEAM_STEP == 0) {

            Team** temp = new Team*[teamCount + TEAM_STEP];

            for (int t=0; t < teamCount; ++t) {

                temp[t] = teamList[t];

            }

            delete [] teamList;

            teamList = temp;

        }
    
    }

}


// See header for description.
//
void Employee::removeTeam(string id) {
    
    // Indicates if we are still searching for the id.
    //
    bool stillLooking = true;
    
    // An index to iterate through the team collection.
    //
    int t=0;

    // Try to find the team with the given id. If found, stillLooking will be false, otherwise 
    // it will be true.
    //
    while (stillLooking && t < teamCount) {

        if (teamList[t]->getId() == id) {

            stillLooking = false;

        } else {

            ++t;

        }

    }

    // If we found the team, remove it from the list.
    //
    if (!stillLooking) {

        for (int m=t; m < teamCount - 1; ++m) {

            teamList[m] = teamList[m+1];

        }

        --teamCount;

    }

}


// See header for description.
//
bool Employee::hasTeam(string teamId) const {

    // Indicates if we are still searching for the id.
    //
    bool stillLooking = true;

    // An index to iterate through the team collection.
    //
    int t=0;


    // Try to find the team with the given id. If found, stillLooking will be false, otherwise 
    // it will be true.
    //
    while (stillLooking && t < teamCount) {

        if (teamList[t]->getId() == teamId) {

            stillLooking = false;

        } else {

            ++t;

        }

    }
  
    return !stillLooking;

}


// See header for description.
//
Team* const * Employee::getTeamList() const {

    return teamList;

}


// See header for description.
//
int Employee::getTeamCount() const {

    return teamCount;
    
}
