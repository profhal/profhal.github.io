// Class: EmployeeDatabase
//
// This class manages a collection of employees.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef EMPLOYEEDATABASE_H
#define EMPLOYEEDATABASE_H

#include <string>

#include "Employee.h"
#include "EmployeeResultList.h"

using namespace std;


class EmployeeDatabase {
private:

    // Used to control the growth of the capacity of the employee collection.
    //
    const static int EMPLOYEE_STEP;

    // The collection of employees in the system and the associated counter.
    //
    Employee **employees;
    int employeeCount;

    // A utility operation to increase the capacity of the employee collection when it fills.
    //
    void increaseEmployeeCapacity();

    // Generate a random employee id.
    //
    string generateRandomId() const;

public:
    
    // Constructor.
    // 
    // Prepares the employee database for managing employees.
    //
    EmployeeDatabase();

    // Destructor.
    //
    ~EmployeeDatabase();

    // Loads set of employees from the specified file. The operation returns true if the load was successful and false
    // otherwise.
    //
    // ** THIS OPERATION IS FRAGILE. THE EMPLOYEE DATA FILE MUST BE IN THE EXPECTED FORMAT OR UNEXPECTED RESULTS
    // ** MAY OCCUR
    //
    // The employee data file should be a collection of instances of the following lines:
    // 
    //     -
    //     <enployee id>
    //     <employee first name - no spaces> <employee second name - no spaces>
    //     <is a manager: [true | false]>
    //
    // where the last line would be true if the employee is a manager and false otherwise. The '-' separates employee
    // instances. Here is an example file with three employees, one manager and two staff:
    //
    //     -
    //     957513632
    //     Melvin Peebles
    //     true
    //     -
    //     976310225
    //     Magilla Gorilla
    //     false
    //     -
    //     983426604
    //     Ogee Somethingorother
    //     false
    //
    virtual bool loadEmployeesFromFile(string filepath);


    // Saves the employee data to the specified file. The operation returns true if the save was successful and 
    // false otherwise.
    //
    virtual bool saveEmployeesToFile(string filepath) const;


    // Returns a new employee with the supplied name and, optionally, id provided
    // 
    //    - the id, if supplied and non-empty, contains only digits and is not an id already in use
    //    - the first and last names are not empty and do not contain whitespace (after trimming)
    //
    // If the id supplied is empty (after trimming), a unique employee id will be generated.
    // 
    // If the conditions above are not met, the employee is not created and the null pointer 
    // is returned.
    //
    virtual Employee* createEmployee(string firstName, string lastName, string id="");


    // Returns a pointer to the employee with the specified id if there is such an employee in system. If not
    // employee exists with the given id, the null pointer is returned.
    //
    virtual Employee* findEmployeeById(string id);


    // Returns a collection of employees whose first or last name contain the keyword.
    //
    // The user is responsible for deleting the collection object when done with it. 
    //
    virtual EmployeeResultList* findEmployeeByNameKeyword(string keywords) const;


    // Removes the employee from the database and removes the employee from all teams on which the employee
    // is staff. This operation throws BadIdException if the supplied id represents a manager and than manager
    // is the manager of at least one team. Teams have to be deleted before a manager can be deleted.
    //
    virtual void removeEmployee(string id);

    // Provides access to the employee collection.
    //
    virtual const Employee* const * getEmployees();
    virtual int getEmployeeCount() const;

    // Returns true of the supplied id is a valid employee id and false if not.
    //
    // A valid employee id is exactly 9 characters long, starts with a '9', and constains only digits.
    //
    virtual bool isValidId(string id) const;
    virtual bool isValidName(string firstName, string lastName) const;


};

#endif