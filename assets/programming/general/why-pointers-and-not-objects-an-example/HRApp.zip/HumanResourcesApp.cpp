#include "HumanResourcesApp.h"

#include <fstream>
#include <iostream>
#include <string>

#include <cstring>

#include "Employee.h"
#include "EmployeeDatabase.h"
#include "Exceptions.h"
#include "Team.h"
#include "TeamManager.h"
#include "TeamResultList.h"
#include "util.h"

using namespace std;

// See declaration from description.
//
const int ZERO_AS_ASCII = 48;



// See declaration from description.
//
bool HumanResourcesApp::prepareEmployeeDatabase() {

    string userResponse;
    string employeeFilepath;

    bool loadSuccessful = true;


    // Prepare the Employee Database.
    //
    do {

        cout << "Do you want to load employees from a file? (y/n): ";
        getline(cin, userResponse);

        userResponse = toLower(userResponse);
    
    } while (userResponse[0] != 'y' && userResponse[0] != 'n');

    if (userResponse[0] == 'y') {
        
        loadSuccessful = false;

        do {

            cout << "Enter file to load: ";
            getline(cin, employeeFilepath);

            if (employeeDB.loadEmployeesFromFile(employeeFilepath)) {

                cout << "Loaded employee data from file '" + employeeFilepath + "' successfully." << endl;
                loadSuccessful = true;

            } else {
                
                cout << "A problem occurred loading employee data from '" + employeeFilepath + "'." << endl;

                do {

                    cout << "Try again? (y/n)";
                    getline(cin, userResponse);

                    userResponse = toLower(userResponse);
    
                } while (userResponse[0] != 'y' && userResponse[0] != 'n');

            }
            
        } while (!loadSuccessful && tolower(userResponse[0]) == 'y');

    }

    return loadSuccessful;

}



// See declaration from description.
//
bool HumanResourcesApp::prepareTeamManager() {

    const int STAFF_STEP = 10;

    string userResponse;
    string teamFilepath;

    ifstream teamFileIn;

    string data;
    string teamId;
    string teamName;
    string managerId;
    string *staffIds;
    int staffIdCount;

    bool reachedEndOfFile;
    bool allIDsAreValid;

    int t;
    int s;

    Employee *manager;
    Employee *employee;

    Team *team;

    bool loadSuccessful = true;




    // Prepare the Team Manager.
    //
    // - Load teams from file
    // - Use manager id and staff id to look up employees in ED
    // - - Write out an error and ignore any teams with bad employee ids.
    //
    do {

        cout << "Do you want to load team data from a file? (y/n): ";
        getline(cin, userResponse);

        userResponse = toLower(userResponse);
    
    } while (userResponse[0] != 'y' && userResponse[0] != 'n');

    if (userResponse[0] == 'y') {
        
        loadSuccessful = true;

        do {

            cout << "Enter file to load: ";
            getline(cin, teamFilepath);

            teamFileIn.open(teamFilepath);

            if (teamFileIn) {
                
                data = 'x';

                getline(teamFileIn, data);
                
                // The file should start with a - and then valid team data should appear such as:
                // -
                // team id [required]
                // team name (might have spaces) [required]
                // manager id [required]
                // staff id [optional]
                // staff id [optional]
                // -
                // [next team data]
                //
                // Note that there might not be any staff ids and there is no assumption about how 
                // many people are on staff.
                //
                // The file should end with a manager or staff id.
                //
                while (data == "-") {

                    getline(teamFileIn, teamId);
                    getline(teamFileIn, teamName);
                    getline(teamFileIn, managerId);

                    staffIds = new string[STAFF_STEP];
                    staffIdCount = 0;

                    getline(teamFileIn, data);

                    reachedEndOfFile = false;

                    // If we are at the end of the file, that last time data was updated it 
                    // must have been a '-' (loop control). There are two situations now:
                    // 
                    // 1. We read in a hyphen. If so, we must have another team to process.
                    //
                    // 2. We didn't read a hyphen and we've started reading in staff ids. They
                    //    will occur until another hyphen or we hit the end of the file.
                    //
                    while (!reachedEndOfFile && data[0] != '-') {

                        staffIds[staffIdCount++] = data;
                        
                        if (teamFileIn.eof()) {
                            reachedEndOfFile = true;
                        }

                        getline(teamFileIn, data);

                    } // !reachedEndOfFile

                    // Now, validate:
                    //
                    // Look for an existing team with the current id.
                    //
                    const Team* const * currentTeams = teamMgr.getAllTeams();

                    allIDsAreValid = true;

                    t = 0;

                    while (allIDsAreValid && t < teamMgr.getTeamCount()) {

                        if (currentTeams[t]->getId() == teamId) {
                            
                            // Found a repeat team id.
                            //
                            cout << "Found a repeat team id: " + teamId << endl;
                            allIDsAreValid = false;

                        } 

                        ++t;

                    } // allIDsAreValid


                    // Look for an employee with the manager's id. If found, make sure the existing 
                    // employee is a manager. If not, that's a problem.
                    //
                    if (allIDsAreValid) {
    
                        manager = employeeDB.findEmployeeById(managerId);

                        if (manager == nullptr) {
                        
                            // Found a bad manager id
                            //
                            cout << "Can't identify the manager. No employee with id " + managerId << endl;
                            allIDsAreValid = false;

                        } else {

                            if (!manager->getIsManager()) {
                                
                                // Found the employee, but the aren't a manager.
                                //
                                cout << "Non-manager employee specified: " + managerId << endl;
                                allIDsAreValid = false;
                            
                            }

                        }

                    }

                    // Make sure all the staff are in the employee database.
                    //
                    if (allIDsAreValid) {

                        s = 0; 

                        while (allIDsAreValid && s < staffIdCount) {

                            employee = employeeDB.findEmployeeById(staffIds[s]);

                            if (employee == nullptr) {
                            
                                // Found a bad staff id
                                //
                                cout << "Encountered a bad staff id: " + staffIds[s] << endl;
                                allIDsAreValid = false;

                            }

                            ++s;

                        }

                    }

                    // If all the ids are valid, we can add the team to the team manager and populate the staff.
                    //
                    if (allIDsAreValid) {

                        // At this point, we know the team id and manager are good. However, 
                        // the team name might be empty. If so, give it a default value.
                        //
                        team = teamMgr.createTeam(teamName == "" ? "UNDEFINED" : teamName, manager, teamId);

                        for (int s=0; s < staffIdCount; ++s) {

                            team->addStaff(employeeDB.findEmployeeById(staffIds[s]));

                        }
                    
                    }

                }

                teamFileIn.close();

            } else {

                loadSuccessful = false;

            }

            
            if (!loadSuccessful) {

                cout << "There was an issue loading team data from file '" + teamFilepath + "." << endl;

                do {

                    cout << "Try again? (y/n)";
                    getline(cin, userResponse);

                    userResponse = toLower(userResponse);

                } while (userResponse[0] != 'y' && userResponse[0] != 'n');

                if (userResponse[0] != 'y') {

                    cout << "Continuing without loading Team data." << endl;

                    loadSuccessful = true;

                }

            }


        } while (!loadSuccessful && tolower(userResponse[0]) == 'y');

    }

    return loadSuccessful;

}



// See declaration from description.
//
void HumanResourcesApp::doQuit() {

    string userResponse;

    string teamFilepath;
    string employeeFilepath;

    ofstream teamOutFile;
    ofstream employeeOutFile;
    
    const Employee* const * employees;
    const Team* const * teams;

    bool keepTrying;
    bool saveSuccessful;

    
    cout << "Would you like to save the Employee data? (y/n): ";
    getline(cin, userResponse);

    userResponse = toLower(userResponse);

    while (userResponse[0] != 'y' && userResponse[0] != 'n') {

        cout << "Try again. Would you like to save the Employee data? (y/n): ";
        getline(cin, userResponse);

        userResponse = toLower(userResponse);

    }

    if (userResponse[0] == 'y') {

        keepTrying = true;

        while (keepTrying) {

            // Save team data 
            cout << "Enter the file path for the Employee data: ";
            getline(cin, employeeFilepath);

            saveSuccessful = employeeDB.saveEmployeesToFile(employeeFilepath);

            if (!saveSuccessful) {

                cout << "Unable to open '" + employeeFilepath + "'. Would you like to try another location? (y/n): ";
                cin >> userResponse;

                while (tolower(userResponse[0]) != 'y' && tolower(userResponse[0]) != 'n') {

                    cout << "Try again. Would you like to try another location (y/n): ";
                    getline(cin, userResponse);

                    userResponse = toLower(userResponse);

                }

                if (tolower(userResponse[0]) == 'n') {

                    keepTrying = false;

                }

            } else {

                cout << "Team data has been saved." << endl;

                keepTrying = false;

            }

        }    

    }


    cout << "Would you like to save the Team data? (y/n): ";
    getline(cin, userResponse);

    userResponse = toLower(userResponse);

    while (tolower(userResponse[0]) != 'y' && tolower(userResponse[0]) != 'n') {

        cout << "Try again. Would you like to save the Team data? (y/n): ";
        getline(cin, userResponse);

        userResponse = toLower(userResponse);

    }


    if (userResponse[0] == 'y') {

        keepTrying = true;

        while (keepTrying) {

            // Save team data 
            cout << "Enter the file path for the team data: ";
            getline(cin, teamFilepath);

            teamOutFile.open(teamFilepath);

            if (teamOutFile) {

                teams = teamMgr.getAllTeams();

                for (int t=0; t < teamMgr.getTeamCount(); ++t) {

                    teamOutFile << "-" << endl;
                    teamOutFile << teams[t]->getId() << endl;
                    teamOutFile << teams[t]->getName() << endl;
                    teamOutFile << teams[t]->getManager()->getId();

                    if (teams[t]->getStaffCount() > 0) {
                        teamOutFile << endl;
                    }

                    for (int s=0; s < teams[t]->getStaffCount(); ++s) {

                        teamOutFile << teams[t]->getStaff()[s]->getId();

                        if (s < teams[t]->getStaffCount() - 1 || t < teamMgr.getTeamCount() - 1) {

                            teamOutFile << endl;

                        }

                    }

                }

                cout << "Team data has been saved." << endl;

                cout << endl;

                keepTrying = false;


            } else {

                cout << "Unable to open '" + teamFilepath + "'. Would you like to try another location? (y/n): ";
                getline(cin, userResponse);

                userResponse = toLower(userResponse);

                while (userResponse[0] != 'y' && userResponse[0] != 'n') {

                    cout << "Try again. Would you like to try another location (y/n): ";
                    getline(cin, userResponse);

                    userResponse = toLower(userResponse);

                }

                if (userResponse[0] != 'n') {

                    keepTrying = false;

                }

            }

        }


    }

}



// See declaration from description.
//
void HumanResourcesApp::doAddEmployee() {

    string firstName;
    string lastName;
    string response;

    bool isManager;

    Employee* employee;

    cout << "ADD EMPLOYEE" << endl;
    cout << "------------" << endl;
    
    do {
        cout << "Enter first name (no spaces): ";
        getline(cin, firstName);
    } while (hasWhitespace(firstName));

    do {
        cout << "Enter last name (no spaces): ";
        getline(cin, lastName);
    } while (hasWhitespace(lastName));

    do {
        cout << "Is this employee a manager? (y/n): ";
        getline(cin, response);
    } while (tolower(response[0]) != 'y' && tolower(response[0]) != 'n');

    isManager = (tolower(response[0]) == 'y');
    
    try {

        employee = employeeDB.createEmployee(firstName, lastName);

        cout << endl;

        if (employee != nullptr) {
        
            employee->setIsManager(isManager);
            
            cout << "Employee successfully added." << endl;

        } else {

            cout << "An unknown problem occurred while creating the employee." << endl;

        }

    } catch (BadIdException e) {

        cout << "A bad employee id was generated while creating the employee." << endl;

    } catch (BadNameException e) {

        cout << "One of the names is ill-formed: first(" << firstName << "), last(" << lastName << ")" << endl;

    }

    cout << endl;

}



// See declaration from description.
//
void HumanResourcesApp::doEditEmployee() {

    string employeeId;
    string response;

    Employee* employee;

    bool keepTrying = true;


    cout << "Enter id of employee to edit: ";
    getline(cin, employeeId);


    employee = employeeDB.findEmployeeById(employeeId);

    keepTrying = true;

    while (keepTrying && employee == nullptr) {

        cout << "There is no employee with id: " << employeeId << endl;

        do {

            cout << "Try again? (y/n): ";
            getline(cin, response);

            cout << endl;

            response = toLower(response);


        } while (response[0] != 'y' && response[0] != 'n');

        if (response[0] == 'y') {

            employee = employeeDB.findEmployeeById(employeeId);

        } else {

            keepTrying = false;

        }

    }

    if (employee != nullptr) {
        
        cout << endl;
        cout << "** ONLY NAME EDIT SUPPORTED **" << endl;
        cout << endl;

        cout << "Current employee name: "  
             << employee->getFirstName() 
             << " "
             << employee->getLastName()
             << endl;
        
        keepTrying = true;

        while (keepTrying) {
            
            try {

                cout << "Enter new first name: ";
                getline(cin, response);

                employee->setFirstName(response);

                keepTrying = false;

            } catch (BadNameException e) {

                
                cout << "That is a bad first name. Please try again." << endl;
                cout << endl;

            }

        }


        keepTrying = true;

        while (keepTrying) {
            
            try {

                cout << "Enter new last name: ";
                getline(cin, response);

                employee->setLastName(response);

                keepTrying = false;

            } catch (BadNameException e) {

                
                cout << "That is a bad last name. Please try again." << endl;
                cout << endl;

            }

        }

        cout << endl;

    }

}



// See declaration from description.
//
void HumanResourcesApp::doFindEmployee() {

    Employee* employee;

    EmployeeResultList *employees;

    string id;
    string keyword;

    string response;
    
    string optionAsString;
    int option;

    bool badInput = true;
    
    while (badInput) {

        badInput = false;

        cout << "Please select a way to look up an employee:" << endl;
        cout << "1. Find by id." << endl;
        cout << "2. Find by name." << endl;
        cout << "3. Return to main menu." << endl;
        cout << "-------------------------------------------" << endl;
        cout << "Enter choice: ";

        getline(cin, optionAsString);

        if (isdigit(optionAsString[0])) {

            option = optionAsString[0] - ZERO_AS_ASCII;

            if (option < 1 || option > 3) {

                badInput = true;

            }

        } else {

            badInput = true;

        }

    };

    cout << endl;

    switch (option) {
    case 1:

        cout << "Enter id: ";
        getline(cin, id);

        employee = employeeDB.findEmployeeById(id);

        cout << endl;

        cout << "EMPLOYEE DATA" << endl;
        cout << "-------------" << endl;

        if (employee != nullptr) {

            cout << "NAME: "
                 << employee->getLastName()
                 << ", "
                 << employee->getFirstName()
                 << endl;
            
            cout << "ID  : " << employee->getId() << endl;

            cout << "MANAGER: " << (employee->getIsManager() ? "true" : "false") << endl;

            cout << "TEAMS  : ";

            for (int t=0; t < employee->getTeamCount(); ++t) {

                cout << employee->getTeamList()[t]->getId()
                     << ( t < employee->getTeamCount() - 1 ? ", " : "");

            }

            cout << endl;

        } else {

            cout << "No employee found." << endl;

        }

        cout << endl;

        cout << "Press return to continue.";

        getline(cin, response);

        cout << endl;

        break;

    case 2:

        cout << "Enter keyword: ";
        getline(cin, keyword);

        employees = employeeDB.findEmployeeByNameKeyword(keyword);

        cout << endl;

        cout << "EMPLOYEES WITH " << keyword << ": " <<endl;

        cout << "--- --- ---" << endl;

        if (employees->getEmployeeCount() == 0) {

            cout << "No employees found." << endl;

        } else {

            for (int e=0; e < employees->getEmployeeCount(); ++e) {

                const Employee* constantEmployee = employees->getEmployees()[e];

                cout << "NAME   : "
                    << constantEmployee->getLastName()
                    << ", "
                    << constantEmployee->getFirstName()
                    << endl;
                
                cout << "ID     : " << constantEmployee->getId() << endl;

                cout << "MANAGER: " << (constantEmployee->getIsManager() ? "true" : "false") << endl;

                cout << "TEAMS  : ";

                for (int t=0; t < constantEmployee->getTeamCount(); ++t) {

                    cout << constantEmployee->getTeamList()[t]->getId()
                        << ( t < constantEmployee->getTeamCount() - 1 ? ", " : "");

                }

                cout << endl;

                cout << "--- --- ---" << endl;

            }

        }

        delete employees;

        cout << endl;

        cout << "Press return to continue.";

        getline(cin, response);

        cout << endl;

        break;

    case 3:
    
        cout << endl << "Returning to main menu." << endl << endl;

    default:

        cout << "Encounterd an unexpected option: "<< option << endl << endl;

    }

}



// See declaration from description.
//
void HumanResourcesApp::doRemoveEmployee() {

    string id;
    string response;

    Employee* employee;

    bool keepTrying = true;


    while (keepTrying) {

        cout << "Enter id of employee to remove: ";
        getline(cin, id);

        employee = employeeDB.findEmployeeById(id);

        if (employee == nullptr) {

            do {

                cout << "No employee found with id: " << id << endl;
                cout << "Try again? (y/n): ";
                getline(cin, response);

                cout << endl;

                response = toLower(response);

            } while (response[0] != 'y' && response[0] != 'n');

            if (response[0] == 'n') {

                keepTrying = false;

            }

        } else {

            keepTrying = false;

            cout << endl;

            cout << "EMPLOYEE DATA" << endl;
            cout << "-------------" << endl;

            cout << "NAME: "
                 << employee->getLastName()
                 << ", "
                 << employee->getFirstName()
                 << endl;
            
            cout << "ID  : " << employee->getId() << endl;

            cout << "MANAGER: " << (employee->getIsManager() ? "true" : "false") << endl;

            cout << "TEAMS  : ";

            for (int t=0; t < employee->getTeamCount(); ++t) {

                cout << employee->getTeamList()[t]->getId()
                     << ( t < employee->getTeamCount() - 1 ? ", " : "");

            }

            cout << endl << endl;

            cout << "Do you want to delete this employee? (y/n): ";
            getline(cin, response);

            response = toLower(response);

            while (response[0] != 'y' && response[0] != 'n') {

                cout << "Try again. Do you want to delete this employee? (y/n): ";
                getline(cin, response);

                response = toLower(response);

            }

            cout << endl;

            if (response[0] == 'y') {
                
                try {
    
                    employeeDB.removeEmployee(id);
                
                    cout << "Employee has been removed. Press return to continue.";

                } catch (BadIdException e) {

                    cout << "You can't delete a manager who is a manager of a team. First, delete all teams the manager manages."
                         << endl;

                    cout << "Press return to continue."
                         << endl;
                }


            } else {

                cout << "Remove employee cancelled. Press return to continue." << endl;

            }

            getline(cin, response);

            cout << endl;

        }

    }

}



// See declaration from description.
//
void HumanResourcesApp::doAddTeam() {
     
    // Used to capture the user's input of the team's id and name.
    //
    string name;
    string managerId;

    // A general purpose string for gathering various user input.
    //
    string response;

    // Used to capture the user's input of the id of a staff member to add to the staff list.
    //
    string staffId;

    // 
    bool keepTrying;
    
    bool createTeam;

    // The manager to manage the team being created.
    //
    Employee* manager;
    
    // A staff member to add to the team being created.
    //
    Employee* staff;
    
    // The created team.
    //
    Team* team;

  
    cout << "Add Team" << endl;
    cout << "--------" << endl;
    
    // Get the name of the team being created. Keep prompting the user until they enter a valid name.
    //
    cout << "Enter team name: ";
    getline(cin, name);

    name = trim(name);

    while (name == "") {

        cout << "The name cannot be the empty string. Enter team name: ";

        getline(cin, name);

        name = trim(name);

    }

    keepTrying = true;
    createTeam = false;

    // 
    while (keepTrying) {

        cout << "Enter manager id: ";
        getline(cin, managerId);

        manager = employeeDB.findEmployeeById(managerId);

        if (manager == nullptr) {

            cout << "Employee not found. Try again (y/n)? ";
            getline(cin, response);

            keepTrying = tolower(response[0]) == 'y';

        } else if (!manager->getIsManager()) {

            cout << "Employee is not a manager. Try again (y/n)? ";
            getline(cin, response);

            keepTrying = tolower(response[0]) == 'y';

        } else {
            
            keepTrying = false;
            createTeam = true;

        }

    }

    if (createTeam) {

        team = teamMgr.createTeam(name, manager);

        staffId = "";

        keepTrying = true;

        while (keepTrying && staffId != "quit") {

            cout << "Enter staff id ('quit' to quit): ";
            getline(cin, staffId);

            staff = employeeDB.findEmployeeById(staffId);

            if (staff != nullptr) {
    
                team->addStaff(employeeDB.findEmployeeById(staffId));

                cout << "Staff member successfully added." << endl;

            } else if (staffId != "quit") {

                cout << "There is no employee with id: " + staffId << endl;

            }

        }

        cout << "Team successfully created." << endl << endl;
    
    } else {

        cout << "Team not created." << endl << endl;

    }
    
    
    cout << "Press return to continue.";

    getline(cin, response);

    cout << endl;

}



// See declaration from description.
//
void HumanResourcesApp::doEditTeam() {
    
    // The id of the team to edit.
    //
    string teamId;
    
    // A general purpose string for accepting user input.
    //
    string response;

    // The team associated to the team id.
    //
    Team* team;

    // Used to indicate the user wants to continue trying to enter a team id if what they have entered
    // does not referene a team in the team manager's collection.
    //
    bool keepTrying = true;


    // Get the team id.
    //
    cout << "Enter id of team to edit: ";
    getline(cin, teamId);


    // Try to find the team with the entered id. Allow the user to keep trying, or not, to enter
    // a valid team id.
    //
    team = teamMgr.findTeamById(teamId);

    keepTrying = true;

    while (keepTrying && team == nullptr) {

        cout << "There is no team with id: " << teamId << endl;

        do {

            cout << "Try again? (y/n): ";
            getline(cin, response);

            response = toLower(response);

        } while (response[0] != 'y' && response[0] != 'n');

        if (response[0] == 'y') {

            team = teamMgr.findTeamById(teamId);

        } else {

            keepTrying = false;

        }

    }

    // If we have a valid team, allow the user to edit the team.
    //
    // NOTE: Only name editing is currently supported.
    //
    if (team != nullptr) {
        
        cout << endl;
        cout << "** ONLY NAME EDIT SUPPORTED **" << endl;
        cout << endl;


        // Display the current team name and get the new name from the user, continuing to ask until
        // a valid name has been entered or the user wants to give up. Once a valid team name is 
        // obtained, update the team and pause to wait for the user to want to continue.
        //
        cout << "Current team name: " << team->getName() << endl;
        
        keepTrying = true;

        while (keepTrying) {
            
            try {

                cout << "Enter team name: ";
                getline(cin, response);

                team->setName(response);

                keepTrying = false;

                cout << "Team name successfully changed. Press return to continue.";

                getline(cin, response);

                cout << endl;

            } catch (BadNameException e) {
                
                cout << "That is a bad team name. Would you like to try again? (y/n): " << endl;
                getline(cin, response);

                response = toLower(response);

                cout << endl;

                while (response[0] != 'y' && response[0] != 'n') {

                    cout << "Would you like to try again? (y/n): " << endl;
                    getline(cin, response);

                    response = toLower(response);

                    cout << endl;

                }


                keepTrying = (response[0] == 'y');

            }

        }


    }
    

}



// See declaration from description.
//
void HumanResourcesApp::doFindTeam() {
    
    // The found team when searching by id.
    //
    Team* team;

    // The team list found be searching by keyword.
    //
    TeamResultList *teams;

    // The id of the team to searh for.
    //
    string id;

    // The keyword to search for.
    //
    string keyword;

    // A general response string for user input. 
    //
    string response;
    
    // The initial response string when choosing an option. We then convert the first character to 
    // a digit and store it in option.
    //
    string optionAsString;
    int option;

    // Indicates we have bad input. Initializes to true to get into the main loop.
    //
    bool badInput = true;
    

    // Prompt the user for an option, reprompting if the input isn't valid.
    //
    while (badInput) {
  
        // Toggle bad input to false. It will switch to true if the user enters an invalid option.
        //
        badInput = false;

        // Show the prompt and decode the response, or indcate the user entered an invalid option 
        // and try again.
        //
        cout << "Please select a way to look up a team:" << endl;
        cout << "1. Find by id." << endl;
        cout << "2. Find by name." << endl;
        cout << "3. Return to main menu." << endl;
        cout << "-------------------------------------------" << endl;
        cout << "Enter choice: ";

        getline(cin, optionAsString);

        if (isdigit(optionAsString[0])) {

            option = optionAsString[0] - ZERO_AS_ASCII;

            if (option < 1 || option > 3) {

                badInput = true;

            }

        } else {

            badInput = true;

        }

    };

    cout << endl;

    // Take the appropriate search action...
    //
    switch (option) {
    case 1:
        
        // Here we are going to find the team by id. So, get the id. 
        //
        cout << "Enter id: ";
        getline(cin, id);


        // Retrieve the team and display the results. If the team is not found, 
        // indicate that no team was found.
        //
        team = teamMgr.findTeamById(id);

        cout << endl;

        cout << "TEAM DATA" << endl;
        cout << "-------------" << endl;

        if (team != nullptr) {

            cout << "NAME: " << team->getName() << endl;
            
            cout << "ID  : " << team->getId() << endl;

            cout << "MANAGER: " 
                 << team->getManager()->getLastName() 
                 << ", " 
                 << team->getManager()->getFirstName()
                 << " ("
                 << team->getManager()->getId()
                 << ")"
                 << endl;

            cout << "TEAM MEMBERS: " << endl;

            for (int t=0; t < team->getStaffCount(); ++t) {

                cout << "   > "
                     << team->getStaff()[t]->getLastName() 
                     << ", " 
                     << team->getStaff()[t]->getFirstName()
                     << " ("
                     << team->getStaff()[t]->getId()
                     << ")"
                     << endl;

            }

            cout << endl;

        } else {

            cout << "No team found with id:" << id << endl;

            cout << endl;

        }

        cout << endl;
        
        // Pause util the user is ready to continue.
        //
        cout << "Press return to continue.";

        getline(cin, response);

        break;

    case 2:
        
        // Here, we look for a teams based on a keyword appearing in their titles. So, get the keyword. Since
        // we aren't interested in case, convert the string to lowercase. And we'll trim it while we're here.
        //
        cout << "Enter keyword: ";
        getline(cin, keyword);

        keyword = toLower(keyword);
        keyword = trim(keyword);


        // Try to find the teams and output each team's information. If no team we're found, output that 
        // message.
        //
        teams = teamMgr.findTeamsByKeyword(keyword);

        cout << endl;

        cout << "TEAMS WITH " << keyword << ": " <<endl;

        cout << "--- --- ---" << endl;

        if (teams->getTeamCount() == 0) {

            cout << "No teams found." << endl;

        } else {

            for (int e=0; e < teams->getTeamCount(); ++e) {

                const Team* constantTeam = teams->getTeams()[e];

                cout << "NAME   : " << constantTeam->getName() << endl;                
                cout << "ID     : " << constantTeam->getId() << endl;
                cout << "MANAGER: " 
                     << constantTeam->getManager()->getLastName() 
                     << ", " 
                     << constantTeam->getManager()->getFirstName()
                     << " ("
                     << constantTeam->getManager()->getId()
                     << ")"
                     << endl;

                cout << "TEAM MEMBERS: " << endl;

                for (int t=0; t < constantTeam->getStaffCount(); ++t) {

                    cout << "   > "
                        << constantTeam->getStaff()[t]->getLastName() 
                        << ", " 
                        << constantTeam->getStaff()[t]->getFirstName()
                        << " ("
                        << constantTeam->getStaff()[t]->getId()
                        << ")"
                        << endl;

                }

                cout << endl;
                cout << "--- --- ---" << endl;

            }

        }

        cout << endl;
        
        // We are done with the team list. It's on us to destroy it.
        //
        delete teams;
        

        // Pause until the user is ready to continue.
        //
        cout << "Press return to continue.";

        getline(cin, response);

        cout << endl;

        break;

    case 3:
        
        // The user opted to return to the main menu. There, really isn't anything to do.
        //
        cout << endl << "Returning to main menu." << endl << endl;

    default:
        
        // This code should never execute, but we will leave it in to handle problems with future
        // enhancements.
        //
        cout << "Encounterd an unexpected option: "<< option << ". "
             << "Returning to main menu." << endl << endl;

    }

}



// See declaration from description.
//
void HumanResourcesApp::doRemoveTeam() {
    
    // The id of the team to remove entered by the user.
    //
    string teamId;

    // A general purpose string for catching user input (e.g. "Press enter to continue.")
    //
    string response;

    // The staff on the team and the manager.
    //
    Employee* const * staff;
    Employee* manager;

    // Indicates we should keep trying to get good input from the user. 
    //
    bool keepTrying;

    // The index in the team collection of the team to be removed.
    //
    int indexToRemove;

    // The team with the provided id.
    // 
    Team* team;
    

    // Get the team id.
    //
    cout << "Enter the id of the team you would like to remove: ";
    getline(cin, teamId);

    // If the id entered is not in the collection of teams, reprompt the user to try again (keepTrying is true) 
    // or give up (keepTrying is false).
    //
    do {

        team = teamMgr.findTeamById(teamId);

        keepTrying = true;

        if (team == nullptr) {

            cout << "Team with id " << teamId << " doesn't exist." << endl;
            cout << "Would you like to enter another id? (y/n): ";
            getline(cin, response);

            response = toLower(response);

            while (response[0] != 'y' && response[0] != 'n') {

                cout << "Try again. Would you like to enter another id? (y/n): ";

                getline(cin, response);

                response = toLower(response);

            }


            if (response[0] == 'y') {

                cout << "Enter the id of the team you would like to remove: ";
                getline(cin, teamId);
                
                team = teamMgr.findTeamById(teamId);

            } else {

                keepTrying = false;

            }

        }

    } while (keepTrying && team == nullptr);


    // If we have a valid team, remove the team, let the user know it worked, and return to the
    // main menu. Otherwise, the user opted to stop trying to find the team and in such a case we
    // just return to the main menu.
    //
    if (team != nullptr) {

        teamMgr.removeTeam(team->getId());

        team = nullptr;

        cout << "Team removed successfully." << endl;

        cout << endl;

        cout << "Press return to continue.";

        getline(cin, response);

        cout << endl;

    }

}



// See declaration from description.
//
void HumanResourcesApp::startInterface() {

    // Used to conver characer digits to integer digits. For example, given a character like 
    // '5', 
    // 
    //     int i = '5' - ZERO_AS_ASCII
    //
    // will result in 5 being stored in i.
    //
    const int ZERO_AS_ASCII = 48;

    // Indicates we should keep the interface running.
    //
    bool keepGoing = true;
    
    // Indicates the user entered bas input.
    //
    bool badInput;

    // We read in the option from the console as a string and convert it to an integer to be able to 
    // decide what menu action to take.
    //
    string optionAsString;
    int option;


    // While the interface should keep running...
    //
    while (keepGoing) {
        
        // Get the menu option from the user.
        //
        badInput = true;

        while (badInput) {

            badInput = false;

            // NOTE: The options must be in the same order as the enum Action.
            //
            cout << "Please make a selection:" << endl;
            cout << "1. Add Employee" << endl;
            cout << "2. Edit Employee" << endl;
            cout << "3. Remove Employee" << endl;
            cout << "4. Find Employee" << endl;
            cout << "5. Add Team" << endl;
            cout << "6. Edit Team" << endl;
            cout << "7. Remove Team" << endl;
            cout << "8. Find Team" << endl;
            cout << "9. Quit" << endl;
            cout << "-------------------------" << endl;
            cout << "Enter choice: ";
            getline(cin, optionAsString);
             
            // Convert the first character of the input string to an integer if the chatacer is a 
            // digit. Otherwise, indicate we have bad input and have the user try again.
            // 
            if (isdigit(optionAsString[0])) {    

                option = optionAsString[0] - ZERO_AS_ASCII;

                if (option < 1 || option > 9) {

                    badInput = true;

                }
            
            } else {

                badInput = true;

            }

            if (badInput) {
    
                cout << endl << "Try again." << endl << endl;

            }

        }

        cout << endl << endl;

        // Translate the option to the appropriate menu action.
        //
        switch (option - 1) {
        case ADD_EMPLOYEE:

            doAddEmployee();
            break;
        
        case ADD_TEAM:

            doAddTeam();
            break;

        case FIND_EMPLOYEE:

            doFindEmployee();
            break;

        case FIND_TEAM:

            doFindTeam();
            break;

        case REMOVE_EMPLOYEE:

            doRemoveEmployee();
            break;

        case REMOVE_TEAM:

            doRemoveTeam();
            break;
        
        case EDIT_EMPLOYEE:

            doEditEmployee();
            break;

        case EDIT_TEAM:

            doEditTeam();
            break;

        case QUIT:

            doQuit();
            keepGoing = false;
            break;

        default:
            
            // This should never execute, but it's here in case future changes result in unexpected options.
            //
            cout << "Unexpected menu option: " << (option - 1) << endl;

        }

    }

}



// See declaration from description.
//
void HumanResourcesApp::run() {

    // Try to prepare the employee database. If the employee database initializes successfully, try to 
    // prepare the team manager. If the team manager initializes successfully, kick off the interface.
    //
    // If one or ther other subsystems doesn't initialize properly, report an error.
    //
    if (prepareEmployeeDatabase()) {    

        cout << "Employee Database is ready to go." << endl << endl;

        if (prepareTeamManager()) {

            cout << "Team Manager is ready to go." << endl << endl;

            startInterface();

            cout << "Goodbye." << endl;

        } else {

            cout << "There was an issue preparing the Team Manager. Terminating." << endl;

        }

    } else {

        cout << "There was an issue preparing the Employee Database. Terminating." << endl;

    }


}
